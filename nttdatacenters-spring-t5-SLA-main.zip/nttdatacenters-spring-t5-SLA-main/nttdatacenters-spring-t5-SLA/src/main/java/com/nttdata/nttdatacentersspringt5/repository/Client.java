package com.nttdata.nttdatacentersspringt5.repository;

// IMPORTS //
import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * Client - Mapeo de la entiad "cliente"
 * 
 * @author Santiago López
 *
 */
@Entity
@Table (name="Cliente")
public class Client implements Serializable{
	// ATRIBUTOS //	
	/**
	 * SERIAL VERSION
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Mapeo: Atributo ID
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private  int id;
	
	/**
	 * Mapeo: Atributo nombre
	 */
	@Column(name="Nombre")
	private String name;
	
	/**
	 * Mapeo: Atributo apellidos
	 */
	@Column(name="Apellidos")
	private String surname;
	
	/**
	 * Mapeo: Atributo Numero-Dni
	 */
	@Column(name="Numero-Dni")
	private int dniNumber;
	
	/**
	 * Mapeo: Fecha-Nacimiento
	 */
	@Column(name="Fecha-Nacimiento")
	private Date birthDate;

	// MÉTODOS //
	// Getters y setters //	
	/**
	 * getId
	 * 
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	
	/**
	 * setId
	 * 
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * getName
	 * 
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * setName
	 * 
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * getSurname
	 * 
	 * @return the surname
	 */
	public String getSurname() {
		return surname;
	}

	/**
	 * setSurname
	 * 
	 * @param surname the surname to set
	 */
	public void setSurname(String surname) {
		this.surname = surname;
	}

	/**
	 * getDniNumber
	 * 
	 * @return the dniNumber
	 */
	public int getDniNumber() {
		return dniNumber;
	}

	/**
	 * setDniNumber
	 * 
	 * @param dniNumber the dniNumber to set
	 */
	public void setDniNumber(int dniNumber) {
		this.dniNumber = dniNumber;
	}

	/**
	 * getBirthDate
	 * 
	 * @return the birthDate
	 */
	public Date getBirthDate() {
		return birthDate;
	}

	/**
	 * setBirthDate
	 * 
	 * @param birthDate the birthDate to set
	 */
	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

	/**
	 * getSerialversionuid
	 * 
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	// toString //
	@Override
	public String toString() {
		return "Client [id=" + id + ", name=" + name + ", surname=" + surname + ", dniNumber=" + dniNumber
				+ ", birthDate=" + birthDate + "]";
	}				
	
}
