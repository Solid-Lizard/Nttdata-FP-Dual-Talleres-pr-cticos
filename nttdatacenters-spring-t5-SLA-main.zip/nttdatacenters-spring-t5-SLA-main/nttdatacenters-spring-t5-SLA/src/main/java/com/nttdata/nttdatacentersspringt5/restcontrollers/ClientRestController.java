package com.nttdata.nttdatacentersspringt5.restcontrollers;

// IMPORTS //
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nttdata.nttdatacentersspringt5.repository.Client;

import java.util.HashMap;
import java.util.Map;

/**
 * 
 * ClientRestController - Controlador REST con operaciones CRUD de le entidad "Clientes", 
 * contiene un repositorio simulado.
 * 
 * @see Client
 * 
 * @author Santiago López
 *
 */
@RestController
@RequestMapping("/home/clients")
public class ClientRestController {
	// ATRIBUTOS //
	/**
	 * Constante: Mensaje de cliente creado satisfactoriamente
	 */
	private static final String CREADO_CLIENTE = "Creado cliente {}";

	/**
	 * Logger: Log de la aplicación
	 */
	private static final Logger LOG = LoggerFactory.getLogger(ClientRestController.class);
	
	/**
	 * Mapa: Repositorio simulado
	 */
	private Map<Integer, Client> mapa = new HashMap<>();
	
	// MÉTODOS //
	// Constructor //
	/**
	 * 
	 * ClientRestController - Constructor vacío, genera una serie de clientes para simular el repositorio
	 * 
	 */
	public ClientRestController() {
		LOG.info("INICIANDO CREACIÓN DE CLIENTES");
		Client c1 = new Client();
		c1.setId(1);
		c1.setDniNumber(12345678);
		c1.setName("Santiago");
		c1.setSurname("López");
		c1.setBirthDate(new java.util.Date());
		
		mapa.put(c1.getDniNumber(), c1);
		
		LOG.info(CREADO_CLIENTE, c1.getId());
		
		Client c2 = new Client();
		c2.setId(2);
		c2.setDniNumber(87654321);
		c2.setName("Hideo");
		c2.setSurname("Kojima");
		c2.setBirthDate(new java.util.Date());
		
		mapa.put(c2.getDniNumber(), c2);
		
		LOG.info(CREADO_CLIENTE, c2.getId());
		
		Client c3 = new Client();
		c3.setId(3);
		c3.setDniNumber(11122233);
		c3.setName("Solid");
		c3.setSurname("Snake");
		c3.setBirthDate(new java.util.Date());
		
		mapa.put(c3.getDniNumber(), c3);
		
		LOG.info(CREADO_CLIENTE, c3.getId());
		
		Client c4 = new Client();
		c4.setId(4);
		c4.setDniNumber(66666666);
		c4.setName("Doom");
		c4.setSurname("Slayer");
		c4.setBirthDate(new java.util.Date());
		
		mapa.put(c4.getDniNumber(), c4);
		
		LOG.info(CREADO_CLIENTE, c4.getId());
		
		LOG.info("CLIENTES CREADOS SATISFACTORIAMENTE");				
	}
	
	// OTROS //	
	/**
	 * 
	 * searchAll - Devuelve todos los clientes existentes
	 * 
	 * @return
	 * 
	 */
	@GetMapping
	public Map<Integer, Client> searchAll() {
		LOG.info("Buscando todos los clientes");
		return mapa;
	}
	
	/**
	 * 
	 * searchClient - Devuelve un solo cliente
	 * 
	 * @param c - Cliente
	 * 
	 * @return Client
	 * 
	 */
	@GetMapping(path="/client", consumes="application/json")
	public Client searchClient(@RequestBody Client c) {
		LOG.info("Buscando cliente: {}", c);
		return mapa.get(c.getDniNumber());
	}
	
	/**
	 * 
	 * addClient - Añade un cliente al repositorio
	 * 
	 * @param c - Client
	 * 
	 */
	@PostMapping
	public void addClient(@RequestBody Client c) {
		LOG.info("Añadiendo cliente: {}", c);
		mapa.put(c.getDniNumber(), c);
	}
	
	/**
	 * 
	 * deleteClient - Elimina un cliente con la misma clave del repositorio
	 * 
	 * @param clave
	 * 
	 */
	@DeleteMapping(value = "/{clave}")
	public void deleteClient(final @PathVariable Integer clave) {
		LOG.info("Eliminando cliente con dni: {}", clave);
		mapa.remove(clave);
	}
		
	
}
