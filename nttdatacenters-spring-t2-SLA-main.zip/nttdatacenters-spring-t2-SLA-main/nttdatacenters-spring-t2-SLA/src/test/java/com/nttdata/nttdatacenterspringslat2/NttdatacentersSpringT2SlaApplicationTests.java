package com.nttdata.nttdatacenterspringslat2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NttdatacentersSpringT2SlaApplicationTests {

	@Test
	void contextLoads() {
	}

}
