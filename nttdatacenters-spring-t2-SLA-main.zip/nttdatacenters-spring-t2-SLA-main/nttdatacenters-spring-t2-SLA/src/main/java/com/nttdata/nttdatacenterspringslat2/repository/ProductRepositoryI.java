package com.nttdata.nttdatacenterspringslat2.repository;

// IMPORTS //
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * 
 * ProductRepositoryI - Repositorio que gestiona la entidad "Producto"
 * 
 * @see Producto
 * 
 * @author Santiago López
 *
 */
@Repository
public interface ProductRepositoryI extends JpaRepository<Product, Integer> {
	/**
	 * 
	 * findById - Busca y devuelve un producto según su id
	 * 
	 * @param id
	 * 
	 * @return Product
	 * 
	 */
	public Product findById(int id);
	
	/**
	 * 
	 * findByName - Busca y devuelve una lista de productos según su nombre
	 * 
	 * @param name
	 * 
	 * @return List - Lista de produtos
	 * 
	 */
	public List<Product> findByName(String name);
	
	/**
	 * 
	 * findByOrder - Busca y devuelve una lista de productos según su pedido asignado
	 * 
	 * @param o - Pedido
	 * 
	 * @see Order
	 * 
	 * @return List - Lista de productos
	 * 
	 */
	public List<Product> findByOrder(Order o);
}
