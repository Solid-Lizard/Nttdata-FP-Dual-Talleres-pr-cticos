package com.nttdata.nttdatacenterspringslat2;

// IMPORTS // 
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
// IMPORTS //
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.nttdata.nttdatacenterspringslat2.repository.DeliveryAdress;
import com.nttdata.nttdatacenterspringslat2.repository.Order;
import com.nttdata.nttdatacenterspringslat2.repository.Product;
import com.nttdata.nttdatacenterspringslat2.services.DeliveryParentServiceI;
import com.nttdata.nttdatacenterspringslat2.services.OrderManagementServiceI;
import com.nttdata.nttdatacenterspringslat2.services.ProductManagementServiceI;

/**
 * 
 * NttdatacentersSpringT2SlaApplication - Clase principal de la aplicación
 * 
 * @author Santiago López
 *
 */
@Configuration
@ComponentScan
@EnableAutoConfiguration
@SpringBootApplication
public class NttdatacentersSpringT2SlaApplication implements CommandLineRunner{	
	// ATRIBUTOS //
	// Constantes //
	private static final String PEDIDO = "Pedido {}";
	private static final String CREADO_SATISFACTORIAMENTE = " creado satisfactoriamente";
	private static final String PRODUCTO = "Producto {}";
	
	// Servicios //
	/**
	 * Servicio: Gestión de pedidos
	 */
	@Autowired
	private OrderManagementServiceI orderService;
	
	/**
	 * Servicio: Gestión de productos
	 */
	@Autowired
	private ProductManagementServiceI productService;
	
	/**
	 * Servicio: Gestión de pedidos de península
	 */	
	// Por defecto, el servicio primario es el de península, es por ello que podemos ahorrarnos la etiqueta de qualifier //
	@Autowired
	private DeliveryParentServiceI peninsulaService;
	
	/**
	 * Servicio: Gestión de pedidos de fuera de la península
	 */
	@Autowired
	@Qualifier("NonPeninsulaService")
	private DeliveryParentServiceI nonPeninsulaService;
	
	// LOGS //
	// Usamos los logs por defecto que utiliza spring //
	private static final Logger LOG = LoggerFactory.getLogger(NttdatacentersSpringT2SlaApplication.class);
	
	// MÉTODOS //
	/**
	 * 
	 * main - Método de entrada a la aplicación
	 * 
	 * @param args
	 * 
	 */
	public static void main(String[] args) {
		LOG.info("INICIO DE TRAZA");		
		SpringApplication.run(NttdatacentersSpringT2SlaApplication.class, args);
		
		LOG.info("FIN DE TRAZA");
	}
	
	@Override
	public void run(String... args) throws Exception {	
		
		LOG.info("INICIANDO CREACIÓN DE PRODUCTOS");			
		Product p1 = new Product();
		p1.setId(0);
		p1.setName("Mando PS4");
		p1.setStandardPrice(30);
		
		LOG.info(PRODUCTO, p1.getName() + CREADO_SATISFACTORIAMENTE);			
		Product p2 = new Product();
		p2.setId(0);
		p2.setName("Consola PS4");
		p2.setStandardPrice(300);
		
		LOG.info(PRODUCTO, p2.getName() + CREADO_SATISFACTORIAMENTE);		
		Product p3 = new Product();
		p3.setId(0);
		p3.setName("Mando PS5");
		p3.setStandardPrice(60);
		
		LOG.info(PRODUCTO, p3.getName() + CREADO_SATISFACTORIAMENTE);				
		Product p4 = new Product();
		p4.setId(0);
		p4.setName("Consola PS5");
		p4.setStandardPrice(600);	
		
		LOG.info(PRODUCTO, p4.getName() + CREADO_SATISFACTORIAMENTE);
		
		LOG.info("INICIANDO CREACIÓN DE PEDIDOS");		
		Order o1 = peninsulaService.createOrder(0, "Harrison Ford", null, null);		
		peninsulaService.addProductToAnOrder(o1, p4);
		peninsulaService.addProductToAnOrder(o1, p3);
		
		LOG.info(PEDIDO, o1.getId() + CREADO_SATISFACTORIAMENTE);
					
		Order o2 = nonPeninsulaService.createOrder(0, "Mark Hamill", DeliveryAdress.CANARIAS, null);	
		nonPeninsulaService.addProductToAnOrder(o2, p1);
		nonPeninsulaService.addProductToAnOrder(o2, p2);
		
		LOG.info(PEDIDO, o2.getId() + CREADO_SATISFACTORIAMENTE);
		
		LOG.info("PEDIDOS CREADOS SATISFACTORIAMENTE");
		
		LOG.info("ALMACENANDO PEDIDOS EN BDD");		
		orderService.create(o1);
		orderService.create(o2);
		
		LOG.info("PEDIDOS ALMACENADOS SATISFACTORIAMENTE");
		
		LOG.info("ALMACENANDO PRODUCTOS EN BDD");		
		productService.create(p1);
		productService.create(p2);
		productService.create(p3);
		productService.create(p4);
		
		LOG.info("PRODUCTOS ALMACENADOS SATISFACTORIAMENTE");
		
		LOG.info("---------------- ORDEN PENINSULA ----------------");
		peninsulaService.breakDownOrder(o1);
		
		LOG.info("---------------- ORDEN NO PENINSULA ----------------");
		nonPeninsulaService.breakDownOrder(o2);				
	}
	
}