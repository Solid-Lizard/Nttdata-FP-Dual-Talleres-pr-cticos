package com.nttdata.nttdatacentersspringt3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NttdatacentersSpringT3SlaApplicationTests {

	@Test
	void contextLoads() {
	}

}
