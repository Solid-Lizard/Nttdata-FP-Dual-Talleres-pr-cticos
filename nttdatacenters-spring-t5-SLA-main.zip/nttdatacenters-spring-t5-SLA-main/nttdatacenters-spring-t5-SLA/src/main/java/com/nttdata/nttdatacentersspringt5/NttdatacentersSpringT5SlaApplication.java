package com.nttdata.nttdatacentersspringt5;

// Imports //

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 
 * NttdatacentersSpringT5SlaApplication - Clase principal de la aplicación
 * 
 * @author Santiago López
 *
 */


////////////////////////////////////////////////////////////////////////////
// PORFAVOR, ASEGURESE DE QUE LA CONEXIÓN A MySQL ES CORRECTA             //
// PARA COMPROBARLO, VAYA A --> src>main>resources>application.properties //
////////////////////////////////////////////////////////////////////////////

@SpringBootApplication
public class NttdatacentersSpringT5SlaApplication {
	// MÉTODOS //
	/**
	 * 
	 * main - Método de entrada a la aplicación
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(NttdatacentersSpringT5SlaApplication.class, args);
	}	

}
