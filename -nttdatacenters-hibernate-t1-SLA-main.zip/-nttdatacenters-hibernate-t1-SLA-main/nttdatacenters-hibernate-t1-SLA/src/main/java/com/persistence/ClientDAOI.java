package com.persistence;

/**
 * 
 * ClientDAOI - Interfaz - Interfaz DAO para la entidad "Cliente"
 * 
 * @author Santiago 
 * 
 * @see com.persistence.CommonDAOI
 * 
 * 
 */
public interface ClientDAOI extends CommonDAOI<Client>{
	
}
