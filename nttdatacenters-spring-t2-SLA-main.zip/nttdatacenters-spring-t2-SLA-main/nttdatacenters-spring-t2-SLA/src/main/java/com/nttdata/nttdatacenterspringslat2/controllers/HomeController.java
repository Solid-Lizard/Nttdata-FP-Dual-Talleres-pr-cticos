package com.nttdata.nttdatacenterspringslat2.controllers;

// IMPORTS //
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 
 * HomeController - Controlador de bienvenida
 * 
 * @author Santiago López
 *
 */
@Controller
@RequestMapping("/")
public class HomeController {
	
	/**
	 * 
	 * welcome - Muestra el mensaje de bienvenida a la aplicación
	 * 
	 * @return String - Mensaje de bienvenida
	 * 
	 */
	@GetMapping("/*")
	public @ResponseBody String welcome() {
		return "¡Saludos!, si guieres consultar la lista de pedidos, dirigete a /solicitud/pedidos";
	}
}
