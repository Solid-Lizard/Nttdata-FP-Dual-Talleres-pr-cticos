package com.nttdata.nttdatacentersspringt5.services;

// IMPORTS //
import java.util.List;

import com.nttdata.nttdatacentersspringt5.repository.Client;

/**
 * 
 * ClientManagementServiceI - Servicio de gestión de clientes, se comunica con "ClientRepositoryI"
 * para emplear sus métodos
 * 
 * @see Client
 * @see ClientRepositoryI
 * 
 * @author Santiago López
 *
 */
public interface ClientManagementServiceI {
	
	/**
	 * 
	 * create - Almacena un cliente en la BDD
	 * 
	 * @param c - Cliente
	 * 
	 */
	public void create(Client c);
	
	/**
	 * 
	 * searchById - Devuelve un cliente según su ID
	 * 
	 * @param id
	 * 
	 * @return Client
	 * 
	 */
	public Client searchById(int id);
	
	/**
	 * 
	 * searchByNameAndSurname - Devuelve un cliente según su nombre y apellidos
	 * 
	 * @param name
	 * @param surname
	 * 
	 * @return Client
	 * 
	 */
	public Client searchByNameAndSurname(String name, String surname);
	
	public List<Client> searchAll();
	
	/**
	 * 
	 * update - Actualiza un cliente en la BDD
	 * 
	 * @param c - Cliente
	 * 
	 */
	public void update(Client c);
	
	
	/**
	 * 
	 * delete - Elimina un cliente de la BDD
	 * 
	 * @param c - Cliente
	 * 
	 */
	public void delete(Client c);
	
}
