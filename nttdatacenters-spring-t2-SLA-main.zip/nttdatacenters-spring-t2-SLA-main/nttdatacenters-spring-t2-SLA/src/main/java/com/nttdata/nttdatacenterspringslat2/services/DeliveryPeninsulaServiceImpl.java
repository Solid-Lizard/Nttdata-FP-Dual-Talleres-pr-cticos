package com.nttdata.nttdatacenterspringslat2.services;

// IMPORTS //
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.nttdata.nttdatacenterspringslat2.repository.DeliveryAdress;
import com.nttdata.nttdatacenterspringslat2.repository.Order;
import com.nttdata.nttdatacenterspringslat2.repository.Product;

/**
 * 
 * DeliveryPeninsulaServiceImpl - Implementación de "DeliveryParentServiceI" para los pedidos entregados
 * dentro de la península
 * 
 * @see DeliveryParentServiceI
 * 
 * @author Santiago López
 *
 */
@Service("PeninsulaService")
@Primary
public class DeliveryPeninsulaServiceImpl implements DeliveryParentServiceI {
	// ATRIBUTOS //
	// Logger //
	/**
	 * Logger: Log de la clase
	 */
	private static final Logger LOG = LoggerFactory.getLogger(DeliveryPeninsulaServiceImpl.class);	
	
	// MÉTODOS //
	@Override
	public Order createOrder(int id, String adressee, DeliveryAdress deliveryAdress, List<Product> products) {		
		if (products == null) {
			products = new ArrayList<>();
		}
		
		return new Order(id, adressee, DeliveryAdress.PENINSULA, products);		
	}

	@Override
	public void addProductToAnOrder(Order o, Product p) {
		this.assignPvp(p);
		this.calcPrice(p);
		o.addProduct(p);		
	}

	@Override
	public String breakDownOrder(Order o) {
		LOG.info("Desglosando pedido: ");
		String mssg = o.toString();
		LOG.debug("Pedido desglosado satisfactoriamente, devuelto {}", mssg);
		
		return mssg;	
	}

	@Override
	public void assignPvp(Product p) {
		p.setPvpCost(21);
		
	}

	@Override
	public void calcPrice(Product p) {
		p.setPvpPrice(p.getStandardPrice() + ( (p.getPvpCost() * p.getStandardPrice()) /100) );		
	}			

}
