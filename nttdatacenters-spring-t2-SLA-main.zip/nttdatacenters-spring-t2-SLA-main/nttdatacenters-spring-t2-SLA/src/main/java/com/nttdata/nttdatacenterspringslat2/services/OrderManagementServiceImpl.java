package com.nttdata.nttdatacenterspringslat2.services;

// IMPORTS // 
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nttdata.nttdatacenterspringslat2.repository.DeliveryAdress;
import com.nttdata.nttdatacenterspringslat2.repository.Order;
import com.nttdata.nttdatacenterspringslat2.repository.OrderRepositoryI;

/**
 * 
 * OrderManagementServiceImpl - Implementación del servicio "OrderManagementServiceI"
 * 
 * @see OrderManagementServiceI
 * 
 * @author Santiago López
 *
 */
@Service
public class OrderManagementServiceImpl implements OrderManagementServiceI {
	// ATRIBUTOS //
	/**
	 * Repositorio: Gestión de pedidos
	 * 
	 * @see OrderRepositoryI
	 */
	@Autowired
	private OrderRepositoryI orderDao;
	
	// MÉTODOS //
	
	// Métodos CRUD //
	@Override
	public void create(Order o) {
		orderDao.save(o);		
	}

	@Override
	public Order searchById(int id) {		
		return orderDao.findById(id);
	}	

	@Override
	public List<Order> searchByDeliveryAdress(DeliveryAdress d) {
		return orderDao.findByDeliveryAdress(d.toString());
	}

	@Override
	public void update(Order o) {
		orderDao.save(o);		
	}

	@Override
	public void delete(Order o) {
		orderDao.delete(o);		
	}

	
	// Otros servicios //
	@Override
	public boolean isFromPeninsula(Order o) {
		boolean res = false;
		
		if (o.getDeliveryAdress().equals(DeliveryAdress.PENINSULA.toString())) {
			res = true;
		}
		
		return res;
	}

	@Override
	public List<Order> searchByAdressee(String adresee) {		
		return orderDao.findByAdressee(adresee);
	}
	
	
}
