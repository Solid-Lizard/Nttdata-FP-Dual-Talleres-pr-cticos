package com.nttdata.nttdatacenterspringslat2.services;

// IMPORT //
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nttdata.nttdatacenterspringslat2.repository.Order;
import com.nttdata.nttdatacenterspringslat2.repository.Product;
import com.nttdata.nttdatacenterspringslat2.repository.ProductRepositoryI;

/**
 * 
 * ProductManagementServiceImpk - Implementación de la interfaz "ProductManagementServiceI"
 * 
 * @see ProductManagementServiceI
 * 
 * @author Santiago López
 *
 */
@Service
public class ProductManagementServiceImpl implements ProductManagementServiceI {
	// ATRIBUTOS //
	/**
	 * Repositorio: Gestión de productos
	 * 
	 * @see ProductRepositoryI
	 */
	@Autowired
	private ProductRepositoryI productDao;
	
	// MÉTODOS //
	// Métodos CRUD //
	@Override
	public void create(Product p) {
		productDao.save(p);	
	}

	@Override
	public Product searchById(int id) {
		return productDao.findById(id);
	}

	@Override
	public List<Product> searchByName(String name) {
		return productDao.findByName(name);	
	}

	@Override
	public List<Product> searchByOrder(Order o) {
		return productDao.findByOrder(o);	
	}

	@Override
	public void update(Product p) {
		productDao.save(p);	
	}

	@Override
	public void delete(Product p) {
		productDao.delete(p);	
	}	

}
