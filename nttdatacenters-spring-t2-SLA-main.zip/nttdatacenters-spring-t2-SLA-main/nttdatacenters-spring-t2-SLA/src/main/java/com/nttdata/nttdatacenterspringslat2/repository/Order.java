package com.nttdata.nttdatacenterspringslat2.repository;

// IMPORTS // 
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

/**
 * 
 * Order - Mapeo de la entidad "Pedido"
 * 
 * @author Santiago López
 *
 */
@Entity
@Table(name="Orders")
public class Order {		
	// ATRIBUTOS //
	
	// Log //
	/**
	 * Logger: Log de la clase
	 */
	private static final Logger LOG = LoggerFactory.getLogger(Order.class);
	
	// Mapeos //
	/**
	 * Atributo: Mapeo de el atributo ID
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	
	/**
	 * Atributo: Mapeo de el atributo adressee
	 */
	@Column(name="Adressee")
	private String adressee;
	
	/**
	 * Atributo: Mapeo de el atributo delivery adress
	 */
	@Column(name="DeliveryAdress")
	private String deliveryAdress;
	
	/**
	 * Atributo: Mapeo de el atributo order
	 */
	@OneToMany(mappedBy="order")
	private List<Product> products = new ArrayList<>();	

	// MÉTODOS //
	// Getters y Setters //
	/**
	 * 
	 * getId - Devuelve el Id del producto
	 * 
	 * @return int - Id 
	 * 
	 */
	public int getId() {
		return id;
	}

	/**
	 * 
	 * setId - Asigna un id al pedido
	 * 
	 * @param id - Id del producto
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * 
	 * getAdressee - Devuelve el destinatario del pedido
	 * 
	 * @return String - Destinatario
	 * 
	 */
	public String getAdressee() {
		return adressee;
	}

	/**
	 * 
	 * setAdressee - Asigna un destinatario al pedido
	 * 
	 * @param adressee - Destinatario
	 * 
	 */
	public void setAdressee(String adressee) {
		this.adressee = adressee;
	}

	/**
	 * 
	 * getDeliveryAdress - Devuelve la dirección de entrega del pedido
	 * 
	 * @return String - Dirección de entrega
	 * 
	 */
	public String getDeliveryAdress() {
		return deliveryAdress;
	}

	/**
	 * 
	 * setDeliveryAdress - Asigna una dirección de entrega al pedido
	 * 
	 * @param deliveryAdress - Dirección de entrega
	 * 
	 */
	public void setDeliveryAdress(DeliveryAdress deliveryAdress) {
		this.deliveryAdress = deliveryAdress.toString();
	}

	/**
	 * 
	 * getProducts - Devuelve una lista de productos del pedido
	 * 
	 * @return List - Lista de productos
	 * 
	 */
	public List<Product> getProducts() {
		return products;
	}

	/**
	 * 
	 * setProducts - Asigna una lista de productos al pedido
	 * 
	 * @param products - Lista de productos
	 * 
	 */
	public void setProducts(List<Product> products) {
		this.products = products;
	}
	
	// Constructor //
	/**
	 * 
	 * Order - Constructor completo
	 * 
	 * @param id
	 * @param adressee
	 * @param deliveryAdress
	 * @param products
	 * 
	 * @see Product
	 * 
	 */
	public Order(int id, String adressee, DeliveryAdress deliveryAdress, List<Product> products) {		
		this.id = id;
		this.adressee = adressee;
		this.deliveryAdress = deliveryAdress.toString();
		this.products = products;
	}	
	
	/**
	 * 
	 * Order - Constructor vacío
	 * 
	 */
	public Order() {
		super();
	}
	
	/**
	 * 
	 * addProduct - Añade un producto a la lista de productos.
	 * 
	 * @param p - Producto
	 * 
	 * @see Product
	 * 
	 */
	public void addProduct(Product p) {
		this.products.add(p);
		
		LOG.info("Añadiendo producto: {}", p.getName()  + " al pedido " + this.getId());
		
		p.setOrder(this);
	}

	// toString //
	@Override
	public String toString() {		
		double precio = 0;
		
		for (Product p: this.products) {
			precio+= p.getPvpPrice();
		}
		
		return "Order [id=" + id + ", adressee=" + adressee + ", deliveryAdress=" + deliveryAdress + ", products="
				+ products.toString() + "Precio total del pedido: " + precio + "]";
	}	
		
}
