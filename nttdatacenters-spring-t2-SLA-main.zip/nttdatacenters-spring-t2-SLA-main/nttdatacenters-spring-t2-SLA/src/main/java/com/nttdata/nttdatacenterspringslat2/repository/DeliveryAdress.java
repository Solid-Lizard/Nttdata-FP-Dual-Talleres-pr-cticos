package com.nttdata.nttdatacenterspringslat2.repository;

/**
 * 
 * DeliveryAdress - Contiene las distintas opciones de la dirección de entrega
 * 
 * @author Santiago López
 *
 */
public enum DeliveryAdress {
	CEUTA, MELILLA, CANARIAS, PENINSULA
}
