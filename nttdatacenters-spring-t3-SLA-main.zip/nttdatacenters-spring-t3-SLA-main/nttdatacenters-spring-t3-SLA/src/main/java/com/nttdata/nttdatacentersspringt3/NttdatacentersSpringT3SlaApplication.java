package com.nttdata.nttdatacentersspringt3;

// IMPORTS //
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.nttdata.nttdatacentersspringt3.repository.Client;
import com.nttdata.nttdatacentersspringt3.services.ClientManagementServiceI;

/**
 * 
 * NttdatacentersSpringT3SlaApplication - Clase principal de la aplicación
 * 
 * @author Santiago López
 *
 */
@SpringBootApplication
public class NttdatacentersSpringT3SlaApplication implements CommandLineRunner{

	// ATRIBUTOS //
	/**
	 * Constante: Mensaje de cliente creado satisfactoriamente
	 */
	private static final String CREADO_CLIENTE = "Creado cliente {}";

	/**
	 * Logger: Log de la aplicación
	 */
	private static final Logger LOG = LoggerFactory.getLogger(NttdatacentersSpringT3SlaApplication.class);
	
	/**
	 * Servicio: Servicio de gestión de clientes
	 */
	@Autowired
	private ClientManagementServiceI clientService;
		
	// MÉTODOS //
	/**
	 * 
	 * main - Método de entrada a la aplicación
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(NttdatacentersSpringT3SlaApplication.class, args);
	}
	
	@Override
	public void run(String... args) throws Exception {	
		LOG.info("INICIANDO CREACIÓN DE CLIENTES");
		Client c1 = new Client();
		c1.setId(1);
		c1.setDniNumber(12345678);
		c1.setName("Santiago");
		c1.setSurname("López");
		c1.setBirthDate(new java.util.Date());
		
		LOG.info(CREADO_CLIENTE, c1.getId());
		
		Client c2 = new Client();
		c2.setId(2);
		c2.setDniNumber(87654321);
		c2.setName("Hideo");
		c2.setSurname("Kojima");
		c2.setBirthDate(new java.util.Date());
		
		LOG.info(CREADO_CLIENTE, c2.getId());
		
		Client c3 = new Client();
		c3.setId(3);
		c3.setDniNumber(11122233);
		c3.setName("Solid");
		c3.setSurname("Snake");
		c3.setBirthDate(new java.util.Date());
		
		LOG.info(CREADO_CLIENTE, c3.getId());
		
		Client c4 = new Client();
		c4.setId(4);
		c4.setDniNumber(66666666);
		c4.setName("Doom");
		c4.setSurname("Slayer");
		c4.setBirthDate(new java.util.Date());
		
		LOG.info(CREADO_CLIENTE, c4.getId());
		
		LOG.info("CLIENTES CREADOS SATISFACTORIAMENTE");
		
		LOG.info("ALMACENANDO CLIENTES EN BDD");
		clientService.create(c1);
		clientService.create(c2);
		clientService.create(c3);
		clientService.create(c4);
		LOG.info("CLIENTES ALMACENADOS SATISFACTORIAMENT");
		
		c2.setName("Hidetaka");
		c2.setSurname("Miyazaki");
		clientService.update(c2);			
		
		clientService.delete(c4);
		
		LOG.info("INICIANDO BÚSQUEDA DE CLIENTES");
		clientService.searchById(1);
		clientService.searchByNameAndSurname("Solid", "Snake");
		LOG.info("BÚSQUEDA DE CLIENTES FINALIZADA");
		
		
	}

}
