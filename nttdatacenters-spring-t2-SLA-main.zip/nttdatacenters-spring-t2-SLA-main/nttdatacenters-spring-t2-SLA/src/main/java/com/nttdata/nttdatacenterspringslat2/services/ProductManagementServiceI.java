package com.nttdata.nttdatacenterspringslat2.services;

// IMPORTS //
import java.util.List;

import com.nttdata.nttdatacenterspringslat2.repository.Order;
import com.nttdata.nttdatacenterspringslat2.repository.Product;

/**
 * 
 * ProductManagementServiceI - Servicio de gestión de productos, se comunica con "ProductRepositoryI" para
 * emplear sus métodos
 * 
 * @see Product
 * @see ProductRepositoryI
 * 
 * @author Santiago López
 *
 */
public interface ProductManagementServiceI {
	// Métodos CRUD //	
	/**
	 * 
	 * create - Almacena un producto en la BDD
	 * 
	 * @param p - Producto
	 * 
	 */
	public void create(Product p);
	
	/**
	 * 
	 * searchById - Busca y devuelve un producto de la BDD según su ID
	 * 
	 * @param id
	 * 
	 * @return Product
	 * 
	 */
	public Product searchById(int id);
	
	/**
	 * 
	 * searchByName - Busca y devuelve una lista de productos de la BDD con el mismo nombre
	 * 
	 * @param name
	 * 
	 * @return List - Lista de productos
	 * 
	 */
	public List<Product> searchByName(String name);
	
	/**
	 * 
	 * searchByOrder - Busca y devuelve una lista de productos según el pedido al que pertenecen
	 * 
	 * @param o - Pedido
	 * 
	 * @return List - Lista de productos
	 * 
	 */
	public List<Product> searchByOrder(Order o);
	
	/**
	 * 
	 * update - Actualiza un producto en la BDD
	 * 
	 * @param p - Producto
	 * 
	 */
	public void update(Product p);
	
	/**
	 * 
	 * delete - Elimina un producto de la BDD
	 * 
	 * @param p - Producto
	 * 
	 */
	public void delete(Product p);
	
}
