package com.Nttadta.nttdatacentersspringt1SLA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NttdatacentersSpringT1SlaApplicationTests {

	@Test
	void contextLoads() {
	}

}
