package com.nttdata.nttdatacenterspringslat2.services;

// IMPORTS //
import java.util.List;

import com.nttdata.nttdatacenterspringslat2.repository.DeliveryAdress;
import com.nttdata.nttdatacenterspringslat2.repository.Order;

/**
 * 
 * OrderManagementServiceI - Servicio de gestión de pedidos, se comunica con "OrderRepositoryI" para
 * emplear sus métodos
 * 
 * @see Order
 * @see OrderRepositoryI
 * 
 * @author Santiago López
 *
 */
public interface OrderManagementServiceI {
	// Servicios CRUD //
	/**
	 * 
	 * create - Almacena un pedido en la BDD
	 * 
	 * @param o - Pedido
	 * 
	 */
	public void create(Order o);
	
	/**
	 * 
	 * searchById - Devuelve un pedido con la misma ID en la base de datos
	 *  
	 * @param id
	 * 
	 * @return Order - Pedido devuelto
	 */
	public Order searchById(int id);
	
	/**
	 * 
	 * searchByAdressee - Devuelve una lista de pedidos con un destinatario
	 * 
	 * @param adresee - Destinatario
	 * 
	 * @return List - Lista de pedidos
	 * 
	 */
	public List<Order> searchByAdressee(String adresee);
	
	/**
	 * 
	 * searchByDeliveryAdress - Devuelve una lista de pedidos con la misma dirección de entrega
	 * 
	 * @param d - Dirección de entrega
	 * 
	 * @return List -Lista de pedidos
	 * 
	 */
	public List<Order> searchByDeliveryAdress(DeliveryAdress d);
	
	/**
	 * 
	 * update - Actualiza un pedido de la BDD
	 * 
	 * @param o - Pedido
	 * 
	 */
	public void update(Order o);
	
	/**
	 * 
	 * delete - Elimina un pedido de la BDD
	 * 
	 * @param o - Pedido
	 * 
	 */
	public void delete(Order o);
	
	// Otros métodos //
	/**
	 * 
	 * isFromPeninsula - Evalúa si un pedido se entrega o no en la península
	 * 
	 * @param o - Pedido
	 * 
	 * @return Boolean - True si el pedido se entrega en la península
	 * 
	 */
	public boolean isFromPeninsula(Order o);	
}