package com.nttdata.nttdatacenterspringslat2.repository;

// IMPORTS //
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * 
 * OrderRepositoryI - Repositorio que destiona la entidad Pedido
 * 
 * @see Order
 * 
 * @author Santiago López
 *
 */
@Repository
public interface OrderRepositoryI extends JpaRepository<Order, Integer>{
	/**
	 * 
	 * findById - Busca y devuelve un pedido por un id
	 * 
	 * @param id - ID
	 * 
	 * @return Order - Pedido		
	 * 
	 */
	public Order findById(int id);
	
	/**
	 * 
	 * findByAdressee - Busca y devuelve una lista de pedidos según su destinatario
	 * 
	 * @param adresees
	 * 
	 * @return List - Lista de pedidos
	 * 
	 */
	public List<Order> findByAdressee(String adresees);
	
	/**
	 * 
	 * findByDeliveryAdress - Devuelve una lista de pedidos según su dirección de entraga
	 * 
	 * @param d - Dirección de entrega
	 * 
	 * @return List - Lista de pedidos
	 * 
	 */
	public List<Order> findByDeliveryAdress(String d);
}
