package com.nttdata.nttdatacenterspringslat2.controllers;

// IMPORTS //
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nttdata.nttdatacenterspringslat2.repository.Order;
import com.nttdata.nttdatacenterspringslat2.services.DeliveryParentServiceI;
import com.nttdata.nttdatacenterspringslat2.services.OrderManagementServiceI;

/**
 * 
 * OrdersController - Controlador que se encarga de mostrar los pedidos existentes
 * 
 * @see Order
 * 
 * @author Santiago López
 *
 */
@Controller
@RequestMapping("/solicitud")
public class OrdersController {	
	// ATRIBUTOS //
	// Servicios //
	/**
	 * Servicio: Gestión de pedidos
	 */
	@Autowired
	private OrderManagementServiceI orderService;
	
	/**
	 * Servicio: Servicio de gestión de pedidos de península
	 */	
	// Solo necesitamos el método BreakDown order, que es igual en las dos implementaciones de los servicios //
	@Autowired
	private DeliveryParentServiceI parentService;
		
	// Otros atributos //
	/**
	 * Objeto: Pedido
	 */
	private Order o;
	
	// MÉTODOS //
	
	/**
	 * 
	 * Solicitud - Muestra la información para que el usuario pueda solicitar los pedidos
	 * 
	 * @return String - Mensaje
	 * 
	 */
	@GetMapping("/pedidos")
	public @ResponseBody String solicitud() {								
		return "Para ver el pedido 1, dirigete a /solicitud/pedido1, para ver el pedido 2, dirigete a /solicitud/pedido2";
	}
	
	/**
	 * 
	 * pedido1 - Muestra la información del pedido con ID 1
	 * 
	 * @return String - Información del pedido
	 * 
	 */
	@GetMapping("/pedido1")
	public @ResponseBody String pedido1() {
		o = orderService.searchById(1);	
		return parentService.breakDownOrder(o);
	}
	
	/**
	 * 
	 * pedido2 - Muestra la información del pedido con ID 2
	 * 
	 * @return String - Información del pedido
	 * 
	 */
	@GetMapping("/pedido2")
	public @ResponseBody String pedido2() {
		o = orderService.searchById(2);
		return parentService.breakDownOrder(o);
	}
	
}
