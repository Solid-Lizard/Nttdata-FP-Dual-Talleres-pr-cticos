package com.nttdata.nttdatacentersspringt3.services;

// IMPORTS //
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nttdata.nttdatacentersspringt3.repository.Client;
import com.nttdata.nttdatacentersspringt3.repository.ClientRepositoryI;

/**
 * 
 * ClientManagementServiceImpl - Implementación de la interfaz "ClientManagementServiceI"
 * 
 * @see ClientManagementServiceI
 * 
 * @author Santiago López
 *
 */
@Service
public class ClientManagementServiceImpl implements ClientManagementServiceI{
	// ATRIBUTOS //
	/**
	 * Logger: Log de la clase
	 */
	private static final Logger LOG = LoggerFactory.getLogger(ClientManagementServiceImpl.class);
	
	/**
	 * Repositorio: Repositorio de cliente
	 */
	@Autowired
	ClientRepositoryI clientRepo;
	
	// MÉTODOS CRUD //
	@Override
	public void create(Client c) {
		LOG.info("Creando cliente: {}", c);
		clientRepo.save(c);		
	}

	@Override
	public Client searchById(int id) {
		LOG.info("Buscando cliente por id: {}", id);
		
		LOG.info("Cliente devuelto {}", clientRepo.findById(id));
		
		return clientRepo.findById(id);
	}

	@Override
	public Client searchByNameAndSurname(String name, String surname) {
		LOG.info("Buscando cliente por nombre y apellidos: {} {}", name, surname);
		
		LOG.info("Cliente devuelto {}", clientRepo.findByNameAndSurname(name, surname));
		
		return clientRepo.findByNameAndSurname(name, surname);
	}

	@Override
	public void update(Client c) {
		LOG.info("Actualizando cliente: {}", c);
		clientRepo.save(c);
		LOG.info("Cliente actualizado satisfactoriamente");
		
	}

	@Override
	public void delete(Client c) {
		LOG.info("Eliminando cliente: {}", c);
		clientRepo.delete(c);
		LOG.info("Cliente eliminado satisfactoriamente");
		
	}

}
