package com.nttdata.nttdatacenterspringslat2.services;
// IMPORTS //
import java.util.List;

import com.nttdata.nttdatacenterspringslat2.repository.DeliveryAdress;
import com.nttdata.nttdatacenterspringslat2.repository.Order;
import com.nttdata.nttdatacenterspringslat2.repository.Product;

/**
 * 
 * DeliveryParentServiceI - Servicio de gestión de entregas de pedidos y sus productos
 * 
 * @see Order
 * @see Product
 * 
 * @author Santiago López
 *
 */
public interface DeliveryParentServiceI {
	/**
	 * 
	 * createOrder - Crea un nuevo objeto de tipo "Order"
	 * 
	 * @see Order
	 * @see Product
	 * 
	 * @param id
	 * @param adressee - Destinatario
	 * @param deliveryAdress - Dirección de entrega
	 * @param products - Lista de productos
	 * 
	 * @return Order - Pedido creado
	 * 
	 */
	public Order createOrder(int id, String adressee, DeliveryAdress deliveryAdress, List<Product> products);
	
	/**
	 * 
	 * addProductToAnOrder - Añade un producto a la lista de productos de un pedido
	 * 
	 * @see Order
	 * @see Product
	 * 
	 * @param o - Pedido
	 * @param p - Producto
	 * 
	 */
	public void addProductToAnOrder(Order o, Product p);
	
	/**
	 * 
	 * breakDownOrder - Devuelve la información de un pedido
	 * 
	 * @param o - Pedido
	 * 
	 * @return String - Información del pedido
	 * 
	 */
	public String breakDownOrder(Order o);
		
	// Otros métodos //
	/**
	 * 
	 * assignPvp - Asigna el porcentaje pvp adecuado en función de la dirección de entrega del producto
	 * 
	 * @see Product
	 * 
	 * @param p - Producto
	 * 	
	 */
	public void assignPvp(Product p);
	
	/**
	 * 
	 * calcPrice - Calcula y asigna el precio total del producto según su porcentaje de pvp
	 * 
	 * @see Product
	 * 
	 * @param p - Producto
	 * 
	 */
	public void calcPrice(Product p);
}
