package com.nttdata.nttdatacenterspringslat2.services;

// IMPORT //
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.nttdata.nttdatacenterspringslat2.repository.DeliveryAdress;
import com.nttdata.nttdatacenterspringslat2.repository.Order;
import com.nttdata.nttdatacenterspringslat2.repository.Product;

/**
 * 
 * DeliveryNonPeninsulaServiceImpl - Implementación de la interfaz "DeliveryParentServiceI"
 * para los pedidos que no son de l apenínsula
 * 
 * @author Santiago López
 * 
 * @see DeliveryParentServiceI
 * @see Order
 *
 */
@Service("NonPeninsulaService")
public class DeliveryNonPeninsulaServiceImpl implements DeliveryParentServiceI{
	// ATRIBUTOS //
	// Logger //
	/**
	 * Logger: Log de la clase
	 */
	private static final Logger LOG = LoggerFactory.getLogger(DeliveryNonPeninsulaServiceImpl.class);	
		
	// MÉTODOS //	
	@Override
	public Order createOrder(int id, String adressee, DeliveryAdress deliveryAdress, List<Product> products) {	
		
		if (deliveryAdress == DeliveryAdress.PENINSULA) {
			deliveryAdress = DeliveryAdress.CEUTA;
		}
		
		if (products == null) {
			products = new ArrayList<>();
		}
		
		return new Order(id, adressee, deliveryAdress, products);		
	}

	@Override
	public void addProductToAnOrder(Order o, Product p) {
		this.assignPvp(p);
		this.calcPrice(p);
		o.addProduct(p);		
	}

	@Override
	public String breakDownOrder(Order o) {	
		LOG.info("Desglosando pedido: ");
		String mssg = o.toString();
		LOG.debug("Pedido desglosado satisfactoriamente, devuelto {}", mssg);
		
		return mssg;
	}

	@Override
	public void assignPvp(Product p) {
		p.setPvpCost(4);		
	}

	@Override
	public void calcPrice(Product p) {
		p.setPvpPrice(p.getStandardPrice() + ( (p.getPvpCost() * p.getStandardPrice()) /100) );
		
	}

}
