package com.nttdata.nttdatacentersspringt5.repository;

// IMPORTS //
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * 
 * ClientRepositoryI - Repositorio de la entidad "Cliente"
 * 
 * @see Client
 * 
 * @author Santiago López
 *
 */
@Repository
public interface ClientRepositoryI extends JpaRepository<Client, Integer>{
	/**
	 * 
	 * findByNameAndSurname - Devuelve un cliente con el mismo nombre y apellidos
	 * 
	 * @param name
	 * @param surname	 
	 * 
	 * @return Client - Cliente
	 * 
	 */
	public Client findByNameAndSurname(String name, String surname);
	
	/**
	 * 
	 * findById - Devuelve un cliente con el mismo Id
	 * 
	 * @param id
	 * 
	 * @return Client - Cliente
	 * 
	 */
	public Client findById(int id);
}
