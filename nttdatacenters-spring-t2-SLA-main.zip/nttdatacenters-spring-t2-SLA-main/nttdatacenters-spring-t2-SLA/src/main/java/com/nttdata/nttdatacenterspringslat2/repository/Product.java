package com.nttdata.nttdatacenterspringslat2.repository;

// IMPPORTS //
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/**
 * 
 * Product - Mapeo de la entidad "Producto"
 * 
 * @author Santiago López
 *
 */
@Entity
@Table(name="Products")
public class Product {
	// ATRIBUTOS //	
	/**
	 * Atributo: Mapeo del atributo "id"
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	
	/**
	 * Atributo: Mapeo del atributo "nombre"
	 */
	@Column(name="Name")
	private String name;
	
	/**
	 * Atributo: Mapeo del atributo "pvpPrice"
	 */
	@Column(name="pvpPrice")
	private double pvpPrice;
	
	/**
	 * Atributo: Mapeo del atributo "standardPrice"
	 */
	@Column (name="standardPrice")
	private double standardPrice;
	
	/**
	 * Atributo: Mapeo del atributo "order"
	 * 
	 * @see Order
	 */
	@ManyToOne
	@JoinColumn(name="Order-Number")
	private Order order;
		
	/**
	 * Atributo: Mapeo del atributo "pvpPercentage"
	 */
	@Column(name="pvp_percentage")
	private int pvpPercentage;

	// MÉTODOS //		
	// Constructor //
	/**
	 * 
	 * Product - Constructor vacío
	 * 
	 */
	public Product() {
		super();
	}

	// Getters y Setters //
	
	/**
	 * 
	 * getId - Devuelve el id del producto
	 * 
	 * @return Id
	 * 
	 */
	public int getId() {
		return id;
	}

	/**
	 * 
	 * setId - Asigna un id al producto
	 * 
	 * @param id - Id del producto
	 * 
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * 
	 * getName - Devuelve el nombre del producto
	 * 
	 * @return String - Nombre
	 * 
	 */
	public String getName() {
		return name;
	}

	/**
	 * 
	 * setName - Asigna un nombre al producto
	 * 
	 * @param name - Nombre
	 * 
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * 
	 * getPvpPrice - Devuelve el precio con el pvp extra
	 * 
	 * @return double - Precio
	 * 
	 */
	public double getPvpPrice() {
		return pvpPrice;
	}

	/**
	 * 
	 * setPvpPrice - Asigna el precio con el pvp extra
	 * 
	 * @param pvpPrice - Precio
	 * 
	 */
	public void setPvpPrice(double pvpPrice) {
		this.pvpPrice = pvpPrice;
	}

	/**
	 * 
	 * getOrder - Devuelve el pedido que tiene asignado el producto
	 *
	 * @see Order
	 * 
	 * @return Order - Pedido
	 * 
	 */
	public Order getOrder() {
		return order;
	}

	/**
	 * 
	 * setOrder - Asigna el pedido al producto
	 * 
	 * @param order
	 * 
	 */
	public void setOrder(Order order) {
		this.order = order;
	}

	/**
	 * 
	 * getStandardPrice - Devuelve el precio estándar del producto
	 * 
	 * @return double - Precio
	 * 
	 */
	public double getStandardPrice() {
		return standardPrice;
	}

	/**
	 * 
	 * setStandardPrice - Asigna el precio estándar del producto
	 * 
	 * @param standardPrice - Precio
	 * 
	 */
	public void setStandardPrice(double standardPrice) {
		this.standardPrice = standardPrice;
	}

	/**
	 * 
	 * getPvpCost - Devuelve el porcentaje sumado al precio pvp del producto
	 * 
	 * @return int - Porcentaje
	 * 
	 */
	public int getPvpCost() {
		return pvpPercentage;
	}

	/**
	 * 
	 * setPvpCost - Asigna el porcentaje sumado al precio pvp del producto
	 * 
	 * @param pvpCost
	 * 
	 */
	public void setPvpCost(int pvpCost) {
		this.pvpPercentage = pvpCost;
	}

	// toString //
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", pvpPrice=" + pvpPrice + ", standardPrice=" + standardPrice
				 + ", pvpPercentage=" + pvpPercentage + "]";
	}	
	
}
